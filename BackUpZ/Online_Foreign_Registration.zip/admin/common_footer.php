
                    </div><!-- contentpanel -->
                    
                </div>
            </div><!-- mainwrapper -->
        </section>

        <script src="js/modernizr.min.js"></script>
        <script src="js/pace.min.js"></script>
        <script src="js/retina.min.js"></script>
        <script src="js/jquery.cookies.js"></script>
        <script src="js/bootstrap-datepicker.min.js"></script>


        <script type="text/javascript" language="javascript" src="js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" language="javascript" src="js/dataTables.bootstrap.min.js"></script>
        <script type="text/javascript" language="javascript" src="js/dataTables.responsive.min.js"></script>
        <script type="text/javascript" language="javascript" src="js/responsive.bootstrap.min.js"></script>

        <script src="js/custom.js"></script>

        <script type="text/javascript">

            $(document).ready(function(){

                $('.exDataTable').DataTable();

            });

        </script>

    </body>
</html>
