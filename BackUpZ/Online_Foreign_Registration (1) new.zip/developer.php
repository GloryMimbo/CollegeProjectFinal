<?php
	$pageNo = "6";
	$pageName = "Developer";
	require_once("common_header.php");
?>

 <!--======= TEAM =========-->
  <section id="team">
    <div class="container"> 
      
      <!--======= TITTLE =========-->
      <div class="tittle">
        <h3>Our great team</h3>
      </div>
      
      <!--======= TEAM MEMBER 1 =========-->
      <div class="row">
        <div class="col-md-6">
          <ul class="row">
            <li class="col-sm-6">
              <div class="team"> 
                
                <!--======= HOVER DETAIL =========-->
                <div class="img"> <img src="assets/images/edo.jpg" alt="" >
                  <h5>EDOUARD MBALA</h5>
                  <p><span>IT Developer, Network Security</span></p>
                </div>
                
                <!--======= HOVER DECTION =========-->
                <div class="bottm-over-t">
                  <div class="btm-detail"> 
                    
                    <!--======= HOVER SOCIAL ICON =========-->
                    <!-- <div class="social_icons">
                      <ul>
                        <li class="facebook"> <a href="#."><i class="fa fa-facebook"></i> </a> </li>
                        <li class="twitter"> <a href="#."><i class="fa fa-twitter"></i> </a> </li>
                        <li class="dribbble"> <a href="#."><i class="fa fa-dribbble"></i> </a> </li>
                        <li class="googleplus"> <a href="#."><i class="fa fa-google"></i> </a> </li>
                        <li class="linkedin"> <a href="#."><i class="fa fa-linkedin"></i> </a> </li>
                        <li class="pinterest"> <a href="#."><i class="fa fa-pinterest"></i> </a> </li>
                      </ul>
                    </div> -->
                    <h5>EDOUARD MBALA</h5>
                    <p><span>IT Developer, Network Security</span></p>
                  </div>
                </div>
              </div>
            </li>
            <!--======= TEAM MEMBER 1 =========-->
            <li class="col-sm-6">
              <div class="team"> 
                
                <!--======= HOVER DETAIL =========-->
                <div class="img"> <img src="assets/images/edo_jeffery.jpg" alt="" >
                  <h5>JEFFREY BOOKE</h5>
                  <p><span>IT Developer, Banking</span></p>
                </div>
                
                <!--======= HOVER DECTION =========-->
                <div class="bottm-over-t">
                  <div class="btm-detail"> 
                    
                    <!--======= HOVER SOCIAL ICON =========-->
                    <!-- <div class="social_icons">
                      <ul>
                        <li class="facebook"> <a href="#."><i class="fa fa-facebook"></i> </a> </li>
                        <li class="twitter"> <a href="#."><i class="fa fa-twitter"></i> </a> </li>
                        <li class="dribbble"> <a href="#."><i class="fa fa-dribbble"></i> </a> </li>
                        <li class="googleplus"> <a href="#."><i class="fa fa-google"></i> </a> </li>
                        <li class="linkedin"> <a href="#."><i class="fa fa-linkedin"></i> </a> </li>
                        <li class="pinterest"> <a href="#."><i class="fa fa-pinterest"></i> </a> </li>
                      </ul>
                    </div> -->
                    <h5>JEFFREY BOOKE</h5>
                    <p><span>IT Developer, Banking</span></p>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="col-md-6">
          <ul class="row">
            <li class="col-sm-6">
              <div class="team"> 
                
                <!--======= HOVER DETAIL =========-->
                <div class="img"> <img src="assets/images/edo_jude.jpg" alt="" >
                  <h5>JUDE KILIOPA</h5>
                  <p><span>IT Developer, Oracle</span></p>
                </div>
                
                <!--======= HOVER DECTION =========-->
                <div class="bottm-over-t">
                  <div class="btm-detail"> 
                    
                    <!--======= HOVER SOCIAL ICON =========-->
                    <!-- <div class="social_icons">
                      <ul>
                        <li class="facebook"> <a href="#."><i class="fa fa-facebook"></i> </a> </li>
                        <li class="twitter"> <a href="#."><i class="fa fa-twitter"></i> </a> </li>
                        <li class="dribbble"> <a href="#."><i class="fa fa-dribbble"></i> </a> </li>
                        <li class="googleplus"> <a href="#."><i class="fa fa-google"></i> </a> </li>
                        <li class="linkedin"> <a href="#."><i class="fa fa-linkedin"></i> </a> </li>
                        <li class="pinterest"> <a href="#."><i class="fa fa-pinterest"></i> </a> </li>
                      </ul>
                    </div> -->
                    <h5>JUDE KILIOPA</h5>
                    <p><span>IT Developer, Oracle</span></p>
                  </div>
                </div>
              </div>
            </li>
            <!--======= TEAM MEMBER 1 =========-->
            <li class="col-sm-6">
              <div class="team"> 
                
                <!--======= HOVER DETAIL =========-->
                <div class="img"> <img src="assets/images/edobenji.jpg" alt="" >
                  <h5>BENJAMIN KAMBA</h5>
                  <p><span>IT Developer, Info Graphics and Designer</span></p>
                </div>
                
                <!--======= HOVER DECTION =========-->
                <div class="bottm-over-t">
                  <div class="btm-detail"> 
                    
                    <!--======= HOVER SOCIAL ICON =========-->
                    <!-- <div class="social_icons">
                      <ul>
                        <li class="facebook"> <a href="#."><i class="fa fa-facebook"></i> </a> </li>
                        <li class="twitter"> <a href="#."><i class="fa fa-twitter"></i> </a> </li>
                        <li class="dribbble"> <a href="#."><i class="fa fa-dribbble"></i> </a> </li>
                        <li class="googleplus"> <a href="#."><i class="fa fa-google"></i> </a> </li>
                        <li class="linkedin"> <a href="#."><i class="fa fa-linkedin"></i> </a> </li>
                        <li class="pinterest"> <a href="#."><i class="fa fa-pinterest"></i> </a> </li>
                      </ul>
                    </div> -->
                    <h5>BENJAMIN KAMBA</h5>
                    <p><span>IT Developer, Info Graphics and Designer</span></p>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

<?php
	require_once("common_footer.php");
?>